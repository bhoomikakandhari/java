// const hug = document.getElementById("hug");

// // Audio context (soft hug sound)
// const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// function playHugSound() {
//   const osc = audioCtx.createOscillator();
//   const gain = audioCtx.createGain();

//   osc.type = "sine";
//   osc.frequency.setValueAtTime(420, audioCtx.currentTime);
//   gain.gain.setValueAtTime(0.12, audioCtx.currentTime);

//   gain.gain.exponentialRampToValueAtTime(
//     0.001,
//     audioCtx.currentTime + 0.4
//   );

//   osc.connect(gain);
//   gain.connect(audioCtx.destination);

//   osc.start();
//   osc.stop(audioCtx.currentTime + 0.4);
// }

// // Hearts + sound loop
// setInterval(() => {
//   playHugSound();

//   const heart = document.createElement("div");
//   heart.className = "heart";
//   heart.innerText = "❤";

//   heart.style.left = Math.random() * 80 + 20 + "px";
//   heart.style.top = "60px";

//   hug.appendChild(heart);

//   setTimeout(() => heart.remove(), 3000);
// }, 900);


const heartBg = document.getElementById("heart-bg");

// Audio context
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playHugSound() {
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = "sine";
  osc.frequency.setValueAtTime(420, audioCtx.currentTime);
  gain.gain.setValueAtTime(0.12, audioCtx.currentTime);

  gain.gain.exponentialRampToValueAtTime(
    0.001,
    audioCtx.currentTime + 0.4
  );

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.4);
}

// Background hearts generator
setInterval(() => {
  const heart = document.createElement("div");
  heart.className = "bg-heart";
  heart.innerText = "❤";

  heart.style.left = Math.random() * 100 + "vw";
  heart.style.fontSize = Math.random() * 20 + 12 + "px";

  heartBg.appendChild(heart);

  setTimeout(() => {
    heart.remove();
  }, 6000);
}, 500);

// Gentle hug sound loop
setInterval(() => {
  playHugSound();
}, 2000);